<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_SQL_SMSBillStateMent_Fit.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHloQoZPzPJ0Bw0NslRFj38yYVRX441EwAfz52C6" +
				"ULCOg29t0SHf2y2Ll6xXBk24dChKCtyOtLTI5HsjIPkAj1tOOOzEf7dU6RB9f0kHrRsGbpPkvwselNVS" +
				"4tom7jI3bOTDJcg7pJHBye+yBf7wbL4iYgPzw8HWMoMOVzK9CG7T9l5Wm67EpTr4KFzQN3FEXDM+m2lk" +
				"H1Eml8uhEBdbU6w9ZFEuKw7u477wl/HBQ5njn8HcGDMC4qvS0hrtUEGzxrlzCGqlRrl62LftWa63DM0r" +
				"E/CicZxSWEPYZHbbnudfCj+zw0EKtFX65tTJIFd/FQcxrqfR8KJVN4I+5si1PIQaijAacFU4TRek+J0Y" +
				"rog6PxM8L1YdwASIW19SsZKlfiQ93iMipkDj+0+5MQJ1R23aW1fUsh8V4a6fo7ruEWuMa3jCmu7jXz62" +
				"j2nGk4xqbyUYSqaz/XG25+Arrbxi2kYhfmKVVbIpjtyXfiUbZEEEAYFZgXIwZNJgy5cvFVzSPJ6qX86B" +
				"dg0Vz43BPGwIhFeWh9b8li4pmg0/iW3tX+HsnZxuLhgXlnxr6w8+emaupeDU+E+RPrkMuTGgFTSmYnc8" +
				"T6Kw54B/NxhPvLBmFF5UhJ2iP7d8dbsEf93LY5liNm1F4e9pehXInQSF4QMXclR02AKf5PSX5/RmVUIr" +
				"GqPKLeXzSlG7mUmQB7RvdfKghQ0DGJawi0/OMcdIIPLKK5wS9grt8LpeECrm75/RQ89chIk98dApjAh5" +
				"O0fHwuMRe5Xv8hgNJGe4b4yHl0BBcjjSCUmXvAKi7HDH5lK30NPgHdxj6lBD3MIhbEZ5GW32DhMyc1Ud" +
				"LLqfK394ysDchRk7gV7HG+JrzVe+3G0Dso8pKzdlMTQn24+QUIGDAB8xSavO+vlCtPOQUmhdYdKi+9LT" +
				"u0MPV217506o2UL7FvuOVTiaXnB9/e3lqSDfg1WftyE2p5HkLFVaRux1aSegF1j8y8ev5eKzIzPZxGM2" +
				"8RwGuvyFf1cc+Vbw3NYEZMfckeE=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_SQL_SMSBillStateMent_Fit.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "RM000012200001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10089";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>