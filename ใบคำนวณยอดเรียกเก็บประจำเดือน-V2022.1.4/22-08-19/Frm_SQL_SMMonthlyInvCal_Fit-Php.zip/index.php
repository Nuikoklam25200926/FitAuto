<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_SQL_SMSBillStateMent_Fit.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnvIA2ThFEIpLS5Lf5pCfGiR05Ndfi7WSKl2AEd" +
				"wNgQHeNp9Nu+sJ/D9JVkSu2pPF3fAQcl2iMXW6o3QaYFYnqTyOxbRd/qar7PKzsT03AMbQmAPtwABkKf" +
				"RHdoYEiCHpubazV+CPmKRRCvkrccnUQXjYvR7tjQBCUQOMBFIpI78mNtepJcjw+LfHPAETBSu2Dlk5wZ" +
				"rddPOndwFw+BAueqz8Xbw076Xp6G1BVq381a6Uj4vtXNB3QgHz5XCrWFVNdI7R9lpf7TK4TcOwzv+8Jo" +
				"0i662CD032TFLfgnZPdlOwY2287bwjvdW8tazQeBIKIqgRo4d0VIAxBFn2igs/j28hYJLC12OtjJ1//U" +
				"fqN+ZNzinfOb+Rc4BHYCf+hp6+87GqlAtuTvjsW3eusBIHsTLt6eQrS2rl3nlUcXFD321sv/Yvqe0hK1" +
				"Ch9UqYRoZwd41mGWTRQXt/4oC1bJPhsOUWI9eEX8KgUwsR26rx7xliR9OoyEMwV0v41g6o92bVo27yM2" +
				"cFjOjQMdrPW5eHaytZSrqXMwUv10C5Av97vrhDyyUMu16qD7Is9mirXSkELWdYfJe6yDbQPCa0YH0p9p" +
				"7Q3V215IJp8OO0Ct1BCZBqBHN1hsq1FBCB2EUzTKc5QecRnyPCBffGxitpFTivwrycsozYRvyf7+DrBd" +
				"bT4B22QdChVZmrZgDdnqdPCVb6JLTWpi7wQ8Bbyad1C/0R63fF1SdERN+wZGk2E2Wt33dvOUhl2JAPSJ" +
				"U1y5+mdNav9Te9gAJFxd/mlN5Zug12IUBJCLvGpS348dxVFGXzqsbjm0nwXyOGTawHUgyNL+DBtFJvGG" +
				"bOvtvkRSa2FpZsEsxjsC1bDliUbYNZf4wGbYSW7qXfjzBJb1kkWr5p32LOz3tgcxqaWpoIV+zH+FU4Xb" +
				"mpcQo0X8eLFuiEVBYHeEZdFWY7a0cS4lcLQpRDpC3ivjdjcD3/mFE3qBXRnmMQieOG0vkfuWEa1Geyet" +
				"C2zAdmGYmVphWRPJaW5lgtA87L8=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_SQL_SMSBillStateMent_Fit.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "RM000012200002";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10089";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>