<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_SQL_SMSBillStateMent_Fit.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHmvSGV7b2U1Rs7UIif8WEl9y89FfP4AChtuQzmc" +
				"+qiXldbVpORNIr5kZjRyFkfNtb7P0fUpK26MhAXxR8qi3vBE6FI/0PTrzDurFlPoWPHI7o5LBY9T57h8" +
				"y6yIwjdcxYWJdnWq37uQSQdX08Yyavn1IVZcdvYZ8UDmgLt2zbxxfUwKw6bxI2eIsli42f4FEPTWVa9R" +
				"GDDVO/K2dDTQPy4r5ph7TAG1NqV/5OEoC/Nt8wJDTkARYgqIBl1eXba/KcCEd3uz7NvZ9t4qjcqUxqZM" +
				"dKz7jNZgfHIDjkVsR9M69UiVCl/qL/zHRGPrIpWxyY21SKABg6R3r05ZeKoLOSRVhqUlb5jvs4oxKNJ+" +
				"wj0wsGtnyFWc79Bw1ccrnT1aKYrN9Vnlak+H5pIRP4VQD2JPxPSInrYoi70auvhN5ld+MZa05WmNptxV" +
				"sBLgx7hG/Td8j2h6Vv/oQJXZ1dFdfUn9b10+S8t/7FXKEVdWKNyNMveYGSDRAxBGPtpJ5wWf4ParLfMu" +
				"GTXwuBcHGFWIPdcJve/JQCsk2dMERYfCcd01N+c4933Ekt242qKWqGnmCskkAnTQfDoYrr9s8Dc4/Zil" +
				"8jUKqJcfsY/pdfb/COBoD3RaHpVIIXSJOgN1YXwYuxiht3ZDeZSQoF90O5JlCJw9aW8EQBBEmrPObrIi" +
				"y6O2rHeO9jjrdPD+IqB43wFdnYl+fVFYcIB1KCVc1cL0haYmDXj1CpkweE9hrCDozf/pwcjIjmherFQ1" +
				"Ult4odolCicZaMk3+Kjrg1kj1Mnoon14he5yGBA8TQIyTjFQhGN+7MypIKUDd32NEKAB3QObiCHS8I+a" +
				"GSO/SEtp7SmdP9JQR6ff3buwrxFHFoqI//yeZSrkNQDgb8jCuywqzobz794XT8Uhu5onLLFgQID0aYdG" +
				"W3DvWv0EyaLf8mM8FQjIhylkOgXAOXwXtrFzjYn1OxeyoyQHnnBOcFiU+IqPGiPOn+uk7GSVGqKn8Vmy" +
				"2cofDRD41xjbOiWfS4eNS4b0ieU=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_SQL_SMSBillStateMent_Fit.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "RM000012200001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10089";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>