<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_SQL_SMSBillStateMent_Fit.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnCoEnO9Yh7T6LNCizkWCA14zUq9Q6Ga/FDwNmf" +
				"OqP3qTXQ7wG8HCA3ASNB44klisHhihecHxjIoT67x6E39wnAvIvR4iBfhGnWV0tcuHqo5PuVSRpG+PLe" +
				"XCiVR1MIdU18MeVXizlNnf2QvM/dbNLPcHoWwgAQTw8FhiW+UweEAlka9krDVTNZcUDRwG164Ix6vwUs" +
				"YYrIvtLZAfKuN6FQg+YT8j/FseDFWpdE3cGi/8HDVN1UncdwdFQb+Op121gGtT6rhcHur7abOeFqthWD" +
				"CC4tPw9rUSK5AmMw5XVMwv64SAaDI+hHo6nkUPYsIzQ8VW32w/onfKJPl7kPHjTNO4gSegoEEn0P3n2K" +
				"6aQ4ORc7wm2jl2RXb/87rHlp/5T8rqggVzBqW0B8dyGr3ouRakODH/vslOlpJbd5RbxGcom9yFoq0FR9" +
				"EY4BCu6ZcSfzLXJD3VaDevFan3FgL0VjHSYpwhwuG0sM1z2+nAQI3g+iISBeQJNXgFh8Vhhyacl5MiFI" +
				"YWuznpCWhYao/cltbxOB7PtyzjyEyXdwZztWfcKfgHaW8fpY2kVzmEx3HMjboIjTVSEpnehuVx8Sz1Z3" +
				"QdPrsfVvp0ngVX8gGKC+4sK6cSkybVGAcSFFhDcUjtG9wbB9QwLeBVCjOFJxfWmFOp5MbR7TW5LVRhjZ" +
				"bq5gXJyTViNESSGTQIe9epfUDfllQEYpvB3oY3reeqj+OxRor+0GVZEGrvwLGtvq/55JUAb9jp7ntJlw" +
				"qoeTUdhI5JfMfzJ2DzAkfg6j2PyDE/Na2UQOfEnWvRWfPVWLWVJbMNu9jqDy+VB5tGi9LJjpaRZA+LO7" +
				"IUAi8Jp1IHFuRsRbOJ7XqRApCAUIiFtbA9VVn4Wp2dJ2nyQHzdRxcGbSQG0Dn1LKDpP/l2/aKlvLs3J/" +
				"FrihaKts5cXxCjnWLMA6cGzZ1VPfLAVDM4FKjAnWdml3t4MrqIkEa0iYbEjecYm3KKW5PWro46ByhIYf" +
				"l5ZGyB1u4cAi67c5eil0IRtGWvQ=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_SQL_SMSBillStateMent_Fit.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "RM10012220000001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10012";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>