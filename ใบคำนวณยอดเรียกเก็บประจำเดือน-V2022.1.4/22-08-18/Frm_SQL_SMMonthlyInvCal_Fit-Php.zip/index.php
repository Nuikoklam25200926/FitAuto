<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_SQL_SMSBillStateMent_Fit.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHnX8O3kbKzMMTuxtGbrVS4HkEbF2J7SHqBy4XKE" +
				"A5cEg3tEfSrVK7AD8XLVc+7Du/UiZXPapObKTUzjlaR7E/TuL2yOD+1HwkhdjoSbCg2//pKOVehMd5HV" +
				"mO6ap54rFKdtnEKR3fJH9lnSrCk88iWd1xgB/KzIHzH5cBBaHConulrVC8XIWOOIltLHqSWmyMwaM93q" +
				"eNpv0GRT7a0S7U3qf3zG7wsoncQ17LxzDUcOcPciGJJr4uhNLbZoNFS4Wt9TxOSp0zUgwvsunrLYR9AD" +
				"W+05+6zfif8i12H1urzfzt0IxOm6VSnRoj5Py8CBS4l+1SmuVwB0OpI7+S0fLdWqH9KvvnBUvwFnM2QG" +
				"l8vbeLEukvm80uIUmzENRWt7haYOjQ2PlyMOHEuyMywOb2wDZlEkDEzDJsRcGyf/oBSzJnZSosen2Eh+" +
				"TCItT2IxT1fm+hhoA7dKmhrofSa1fJ6QtZjms2K3WDUQCwD3uQbJU/gqUQjFpU3+7i5YyZww/X6fiy9W" +
				"AHNsvbwUvzzPlkTXxwm6swQR+30E8GjLS9NvpiOvlCKy8TrK8GGmFbhompO0Fj05KHuw/0Q1Y0fbbZaV" +
				"2FJLlxPxu9TvDfI7hdy8Sn9L+xYvJp3u0BKWQ9SCROWcxVr9vLJZP2YZGsh8X5FjJbgbaYiNgt80Uu0m" +
				"CCcUW0bAIjZc/jUhQRUge+u903QjqbWTsUBRm3A/0nUSimYEabC3J1Hks8xIdNviZcL4448qUdHC6muH" +
				"yVzGu7bZ7lJI82xkq4i6vQe9CKkrzeA3p+8g9qHc52mJMUtlcMm3R0GjQRuxw4rcQvYdaLD6TlGliQKQ" +
				"M40LZP6pkf8mq5yZtBSgUTFZgJMwcjSN1gJMzMITb6UuL1zclxBWzlHPRsWloN0R2z73785jebDANW+9" +
				"QYFeeN+sAxkgPpv7Tf5KmtQMkDHQjcgZYM/atrMBTE1+42Zl3vH9VWwu1iw1UYlELN53mpN2bCqLKf6t" +
				"5hHS6ziTqeerIO6tDuqR0Byfcs0=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_SQL_SMSBillStateMent_Fit.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "RM000012200001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10089";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>