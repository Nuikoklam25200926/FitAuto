<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHmeJXW//BDThdKfTR/QTbMmfViZORW7uMNFXknt" +
				"lejAltsTXyV0zojHA/MhBZarRzK9npK6NIXGE9YEdHJgBJy8s0+tzUyVTrD9sRRWmr7QFTG6/crv5XFH" +
				"YnOdRYVjiKoexHnYsjYj9kv7n1Fb3QU8Pl6X+h7VbpH7PfPtje8o8f9ufHkEBq1XZffiWnm5HKH5KSnh" +
				"jA0Hk+382QbEAyYxiIj1tBQ9xf8KyLK1j0+v7ybhHBP0c5WHkDzrj5ZtNDfWBe1m8YZcvCmt+VYhuGJM" +
				"DVdfUCqqtVgvNPrJqWOjkD5esJr0aWh+biSeLKOvh1IA+AtuGJnBftoMLcT9Jj/jFQZh27SqFxqwijE1" +
				"ftoZUd0MsG2ckPagTG3YkxJ6jhxNO/7eBmCfaqXGxvwj0h80JZB/lXj511GKUmZx++uMH8OV2J3Pzj+x" +
				"mEZh6JDw3G3LuslamC7VC6uIt74R04bCxmscDWD2UpgnqqAgyXMPH7cG7R1XzxfapXXm3L8Hvj5W2Cnn" +
				"TbaapN8hi/O+myEQclMWYXNc5wWMHRFj0qKfji65CeIL+fREW/x/zh6ACI+lV6VM4Kkv/P7p/awA0CdN" +
				"Fuh4Tjk8e+82zinfTrDxhn7WirxYMWVFrrcgYsKKsGYlNWfLACJKsNke4xfK7KqPIor0i5KyD3InB/7m" +
				"pJ4n+JGTjYVQTJVW1om9ZQCvcvAfqVVBKu33/iLtPJ5kh5xRLcIXDrb0SUnWPTG3UdN30/FIrdvUsIbH" +
				"/kWveLT5lLll/qSIErjafWcKeHSbIsCF19x5M+4YuuTcJySu8U4dvkHov8lVUKUyv57oXZ2o5lOsmOt7" +
				"Y0KuTdS3GpzuhzDpNHTMLmDmOABUiB4wi18UbGqz4uWORnLzPFwQn2/scE+zBT4M/ZzOiskqFAaKaOWI" +
				"7sHqa0GC5RnFOxZ5fPO80hmIFceT5ddm97f+6FAOiC/VDctz9/NczCOM/2pbss29JAVKbcI9iBCmcJys" +
				"uNaCoLzTcp+IQ4coWhwyWmKLR2k=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S2200103000010000001";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10100";
			report.dictionary.variables.getByName("ChkAgn").valueObject = "IIF(TCNMFanshine.FTAgnCode==\"\",\"00001\",TCNMFanshine.FTAgnCode)";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>