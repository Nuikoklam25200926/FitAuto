<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHmClIbFKk25lDt2HZbpkjEajObaaHSDsqwmhU7y" +
				"hB6lm6LU9XN8jFdSBCgppQixnTXYkVfWml/Uhx1ACPOK+zSWt3M5H8B7iUD96nBsI+UQSaSgjiupgT8U" +
				"/dxXLAQpq54b8RbNeb822wnMpDJCAqb392fD83cbftqWpVPw/R5fnbf2FV2Ccl91+XVsnjFFYqJ1OTP+" +
				"IacLX+B9aHI+d5D/iV7j0JxsbSObtv77DWfQ4KCWCMMnmJjsJrI8owEn9uXuvBcxinQYpSFy6jq+8mNm" +
				"xCZPauic3bFR80yZ+nZ1UbWS7T19oZF25lA/Q5Je9DCLDfqTV6IcL2//eJVR7VU+5bMdF//iS7QUQ3cl" +
				"chWy+VJpSRWyLvX15sKPoKw+9v99RL3oXs9EdJIx9pRqt07eq+0ezhY7PnrprAZ+KtEL62lcIBHvT40a" +
				"YskXOQwP5T/6omjKkez23olNIra9BVC1lqcFA3cMtXz2V428OL/yjcYcHIcBxIVU0yVJDlrveprlJZce" +
				"AJfpUZLOCVO7p7J8ucem5k3NgCwj05dYe9KjarflrDbmdXctoqFU2l68fO5ViZkO1zs275c/Yfo/1Gtd" +
				"5oZdGc5ogK67ZBr2elMLJ3KJoaMxE5pgX4Pq2ieOEYtMD4je5ulyYwYeGGayoKFOYVS90duppxmUAqNj" +
				"g0dOZDfqBx0nfvj/46UbazR3YExuLAW5cGx8lKWZn5PY1oNbjYnKDvqgPYiepmWIkh08WBL0BNIwi2gL" +
				"akpm7m3PC2a/Ekuo8W+JUtTagsYFMRi3wL22y1sCb/7XcXAlAGCPo496R7ZO0t5Tl3m3BElf1ryDWAdO" +
				"uf7BJKlnhoxSkK4O2GtlrM4pWza1qXh4ZDoJv//m/pde9qQeJzqoBoOODyRGPvDBsb00yfGCqfuwHVBe" +
				"pvqOG2YnO+h559tsLxhQoP++HD2HBiHNwqxaotAIjwjVMPRL6Bku/lryghRe+xUT1I9SQ4O3EMuIDU3q" +
				"KRBOt4QugbqhlsonMcxivHxJvSo=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S2220003000030000002";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "20003";
			report.dictionary.variables.getByName("ChkAgn").valueObject = "IIF(TCNMFanshine.FTAgnCode==\"\",\"00001\",TCNMFanshine.FTAgnCode)";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>