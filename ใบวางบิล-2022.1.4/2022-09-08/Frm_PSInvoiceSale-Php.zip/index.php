<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Frm_PSInvoiceSale.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHkSDVbJkZ7WodvZSgSxd8M4QO4ZyYqNjN1HFQ7L" +
				"ZOzbKyUWYTNPcO+orGCoWHihUAPIIm+54EEB0dnQpV0h0x33dYmjBQ9LkD8U0mnWFxWsLqiLN2LQd9Fi" +
				"uQ19YpqnnKD3rz47zV3rhItnVJh71qcoYLKMrNn/BPeLf87QDDEwt7ailwUHseoEM1s4jd4Yw/ENG2Vj" +
				"HzNWdd1wsZhdeH21JZB78ytfgv0VFRfYNFIUb6N5KKGCPTzbHc0YsXOTsA/b1t3HSmvqapgAwif+5cGx" +
				"d4vz8ReBIXTI9smldtn3hwVzE2vThfDcAzq+435L29T60/nzltzJ1cTLQ4Q+7sBw/rZd3TOy3j41UMDa" +
				"RfbQWu+F5pLnXZqTuEmGKsUvH5zXeMYWfDHCp7szjEbHuV/Kp4e09qVQIGCxKRXPmc1QgiM8ujAsRrxv" +
				"gQ1t5YXd5FlF4ta5jRXukdmQrlgEWzOdkNwxBDU4Sq4bg3vONpcsVv/p8lCgCsHXG2TyAngBjgBKvhq6" +
				"YTjSZa8dgJ9u3R1UuScZ8GLbp7lZ/SRGnAqfBEnv2C+pV90u27Q1GAtpHatI2zH9MjlYFFtz6fe+sxEM" +
				"ESXQxzRkOMtFdzqUfBFfvultvudxQts55eiYBZf1GScfp5Azxl1CcHl6qgX/9ijb4aEP3F8ycV2/iYzs" +
				"qok8cOuw6hosxw91Km/XxwiEsHiht1kRpMdiljGkTXYDcoG+ivRUr2UCXQMgVlYBqyla53dobCDPD8iJ" +
				"uRLLtj4xIJ5WSpzzxRefQ7legaMjPx4K8OPzjBN3pDPu/J6zNJ36jbuqaguZ/7gKrzphtSS8e7G+Q5cs" +
				"wNyp3YBYf9+LKUmZ0EgqmIX0wMhFYidS+EzdVraE55Uo2Lhtnw7ZKvKp/Z5XwRl7BJgRJI/MXFdWyMJe" +
				"b086FNDyGiTcw5WborMXDfpwUSgWepmUmFSXjYPHLWvi/ZBdG7VE+VVFbk7nAkENUSTFtj4qDVn/x1HF" +
				"tOGsyhby1PB/To1daJr1RLsiHqM=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/en.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/Frm_PSInvoiceSale.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 3;
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "S2200007000010000011";
			report.dictionary.variables.getByName("SP_tStaPrn").valueObject = "1";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "00007";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>